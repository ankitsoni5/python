# list of lists is a matrix
'''
[
    [10,20],
    [5,6]
]

'''