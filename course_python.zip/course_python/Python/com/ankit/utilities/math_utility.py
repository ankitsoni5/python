def get_even_odd(number):
    print('Odd Number') if number % 2 else print('Even Number')
    print('----------------------')
    #pass# it signals Python system to ignore the empty block