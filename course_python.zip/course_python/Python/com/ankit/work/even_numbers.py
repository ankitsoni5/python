n = int(input('Enter the number: '))

# Looping
# While Loop

i = 0
while i<=n:
    if not i % 2:
        print(i)
    i = i+1