n = int(input('Enter the number: '))
#if-else use
'''
multi-line comment
Learing if-else
'''
def even_odd(number):
    '''if number % 2:
        print('Odd number')
    else:
        print('Even number')'''
    #It only work when we have only one if-else condition.
    print('Odd Nmber') if number % 2 else print('Even Number')


even_odd(n)